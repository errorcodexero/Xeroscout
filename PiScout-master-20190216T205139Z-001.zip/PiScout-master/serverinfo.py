SERVER = "http://123.123.123.123" # or "http://scout.MyTeamDomain.org, etc.
AUTH = "XXXXXXXXXX"