# PiScout
Scouting system originally developed by FRC 2067 (2016) and continued by FRC 238 (2017)+.

This software implements a "Scantron" style scouting system where information is collected by bubbling in paper forms which are then scanned in and processed by the software. Data is accessible via webpages on a local server with support for an additional remote server to make data accessible over the web.

For more information about the code structure/function, installation/operation, and how to use it for your team, see the Wiki


