import mysql.connector

print("connecting to scouting on local")
conn = mysql.connector.connect(user='root', password='root',
                               host='127.0.0.1',
                               database='scouting')
print("creating cursor")
cur = conn.cursor()

columns = ["intcol", "intcol2",]

query = ("create table foo "
         "(`key` integer primary key,")
for key in columns:
    query += key + " integer, "

query = query[:-2] + ")"
print(query)

cur.execute(query)

columns2 = ["intcol3", "intcol4",]

query = ("create table foo2 "
         "(`key` integer primary key,")
for key in columns2:
    query += key + " integer, "

query = query[:-2] + ")"
print(query)

cur.execute(query)

print("close cursor and connection")
cur.close()
conn.close()
